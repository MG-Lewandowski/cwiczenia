import math

czysiedzieli = 0
zakres = 0
licznik = 0

zakres = int(input("Wpisz zakres np 100: "))
print()
print("-----------")

pierwiastek = math.sqrt(zakres) 

for liczby in range(1, zakres):
    
    licznik = licznik + 1
    if zakres%liczby == 0:
        czysiedzieli = czysiedzieli + 1
        print(czysiedzieli)
    if liczby > pierwiastek:
        break
    #print("Zakres: " + str(zakres) + " dzielony przez " + str(liczby) + " wynosi " + str(x))
    #print(czysiedzieli)
if czysiedzieli > 1:
    print("Liczba " + str(zakres) + " nie jest liczbą pierwszą :((    i co z tym zrobisz   FRAJERZE !!!!!")
else:
    print()
    print("---------------------------------------------------")
    print("***************************************************")
    print("Liczba ----->" + str(zakres) + " <----- jest liczbą pierwszą BRAVO !!!!")    
    print()
    print("***************************************************")
    print("---------------------------------------------------")

print(pierwiastek)
print(licznik)

# Tu zmienić poniższy kod
'''
for number in range(0, 10):
    if number == 5:
        break
    print(number)
'''