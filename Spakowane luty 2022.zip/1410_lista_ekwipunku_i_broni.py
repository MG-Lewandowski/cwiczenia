import random
from random import randint

ekwipunek =["Hełm", "Zbroja", "Rękawice", "Spodnie", "Buty", "Tarcza", "Medalion", "Talizman" "Pierścień_1", "Pierścień_2", "Sygnet", "Peleryna"]

bronie =["miecz_mocy", "miecz_światła", "miecz_haosu", "miecz_władzy", "miecz_potęgi", "miecz_bohatera"]


hełm = ["Hełm_mocy", "rycerz", 1,  50, 8, 200]

aktywna_broń = ['nazwa broni', 'rodzaj broni np. miecz, topór, obuch, broń dystansowa itp',
                'klasa postaci', 'level', 'siła ataku', 'wartość']

drewniany_miecz = ['Drewniany miecz', 'miecz' 'rycerz', 1, 20, 350]

nazwa_hełmu = hełm[0]
klasa_hełmu = hełm[1]
level_hełmu = hełm[2]
hp_hełmu = hełm[3]
obrona_hełmu = hełm[4]
wartość_hełmu = hełm[5]

miecz = ["Miecz mocy", "rycerz", 1, 20, 350]


nazwa_miecza = miecz[0]
klasa_miecza = miecz[1]
level_miecza = miecz[2]
atak_miecza = miecz[3]
wartość_miecza = miecz[4]



print(f'Nazwa hełmu: {nazwa_hełmu}')
print(f'HP hełmu: {hp_hełmu}')
print()
print(f'Wartość miecza wynosi: {wartość_miecza} sztuk złota')


print(type(miecz))



# Zastanowić się czy tworzyc eq i bronie jako listy czy krotki


        
       
print("Tworzę miecze (Listy z zawartością)")
        
for i in range(1, 3):
            
            miecz = []
            atak_miecza = randint(5, 20)
            miecz.append("Miecz mocy")
            miecz.append("Rycerz")
            miecz.append(1)
            miecz.append(atak_miecza)
            miecz.append(200)
            print(miecz)
            print(i)
            
mainlist = []

for i in range(10):
            a = 'nazwa_'
            b = str(i)
            c = a+b
            c = [i]
            mainlist.append((a+b)+'_coś')
            
print(mainlist)


        # Lista z mieczami (krotkami z danymi)
miecze = [] 
      
print("Dodawanie krotki/krotek do listy np. miecze")
       
        
for drop in range (1, 10):
            losowa_liczba = random.randint(1,3)
            #print(losowa_liczba)
            if losowa_liczba == 1:
                tuplecik = ()
                
                miecze.append(tuple(('Miecz Mocy','Rycerz', 1, drop + 5, 200)))
            if losowa_liczba == 2:
                tuplecik = ()
                
                miecze.append(tuple(('Łuk Światła','Łucznik', 1, drop + 15, 300)))

print(miecze)
print(miecze[0])