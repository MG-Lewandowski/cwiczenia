import math

czysiedzieli = 0
zakres = 0
licznik = 0
aktualna_liczba = 0
zakresik = 0
'''
zakres = int(input("Wpisz zakres np 100: "))
print()
print("-----------")

for wszystkie_liczby_z_zakresu in range(1, zakres):

    
    for liczby in range(licznik, aktualna_liczba):
    
        pierwiastek = math.sqrt(aktualna_liczba)


        if aktualna_liczba%liczby == 0:
            czysiedzieli = czysiedzieli + 1
            print(czysiedzieli)
        if liczby > pierwiastek:
            break
    
    if czysiedzieli <= 1:
        print(aktualna_liczba)

print(aktualna_liczba)   

'''

dolny_zakres = int(input ("Podaj dolny zakres: "))  
gorny_zakres = int(input ("Podaj gorny zakres: "))  
  
print ("Liczby pierwsze w podanym zakresie to: ")  
for number in range (dolny_zakres, gorny_zakres + 1):  
    if number > 1:  
        for i in range (2, number):  
            if (number % i) == 0:  
                break  
       # else:  
        #    print (number)  
print(number)    