x = 1

while x > 0:
    x = x + 1
    if x%2 == 1:
        print(x)
    if x == 500:
        break

lista = ["Robert Makłowicz", "Żyć jak Makłowicz :)", 1,2,"a", "b", True, False, 90.5]    
print(lista)
tekst = "Hello World"
lista[2] = tekst
print(lista)
lista2 = [67, 12]
lista[3] = lista2
print(lista2)
print(lista)
print(lista[3][1])
lista3 = [56, 4, 6, 23]

print(lista3)
print(min(lista3))
lista3.sort()
print(lista3)
lista4 = [1,2,3,4,5]
print(lista4)