names_list =["Asia", "Basia", "Jola", "Kasia", "Mariola", "Natalia"]

names_list2 =["Eniu", "Stefan", "Janusz", "Jarosław", "Dariusz", "Marcin", "Piotr", "Paweł", "Robert", "Władysław", "Zbyszek"]

names_list3 = names_list + names_list2

names_list3.sort()


print(names_list3)

krotka = ("Marcin", "Lewandowski", 41)

print(len(krotka))
print(krotka[2])