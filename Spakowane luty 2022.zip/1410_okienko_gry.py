import pygame from 

pygame.init()
