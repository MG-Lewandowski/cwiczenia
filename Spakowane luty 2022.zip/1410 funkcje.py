from random import randint

punkty_doświadczenia = 4444

def jaki_jest_level_postaci(punkty_doświadczenia):

    if punkty_doświadczenia < 101:
        return  1
    elif punkty_doświadczenia < 251:
        return  2
    elif punkty_doświadczenia < 451:
        return 3
    elif punkty_doświadczenia < 731:
        return 4
    elif punkty_doświadczenia < 1131:
        return 5
    elif punkty_doświadczenia < 1701:
        return 6
    elif punkty_doświadczenia < 2601:
        return 7
    elif punkty_doświadczenia < 3801:
        return 8
    elif punkty_doświadczenia < 5801:
        return 9
    elif punkty_doświadczenia >= 5801:
        return 10 

level_postaci = jaki_jest_level_postaci(punkty_doświadczenia) 

print()
print()
print()
print()
print()
print()
print()
print()
print(f'Level postaci: {level_postaci}')





# punkt 10 aktualizacja levela przeniesione z gry 1410, może sie przyda
'''
elif wybor_usera == 10:    
        print()
        print()
        print("Wybrałeś aktualizację levela: ")
        if punkty_doświadczenia >= 0 and punkty_doświadczenia < 101:
            level_postaci = 1
        elif punkty_doświadczenia >= 101 and punkty_doświadczenia < 251:
            level_postaci = 2
        elif punkty_doświadczenia >= 251 and punkty_doświadczenia < 451:
            level_postaci = 3
        elif punkty_doświadczenia >= 451 and punkty_doświadczenia < 731:
            level_postaci = 4
        elif punkty_doświadczenia >= 731 and punkty_doświadczenia < 1131:
            level_postaci = 5
        elif punkty_doświadczenia >= 1131 and punkty_doświadczenia < 1701:
            level_postaci = 6
        elif punkty_doświadczenia >= 1701 and punkty_doświadczenia < 2601:
            level_postaci = 7
        elif punkty_doświadczenia >= 2601 and punkty_doświadczenia < 3801:
            level_postaci = 8
        elif punkty_doświadczenia >= 3801 and punkty_doświadczenia < 5801:
            level_postaci = 9
        elif punkty_doświadczenia >= 5801:
            level_postaci = 10 

        print(f'Level postaci wynosi: {level_postaci}')  
        

for liczba in range(1, 15):


    x = randint(0, 3)
    print(x)
    '''