print(f"Hello {50 * 24*20}")
