# Program sprawdza czy wpisany tekst jest palindromem, potop, ala
'''
tekst = input("Wpisz tekst do obróbki:  ")
tekst_odwrócony = tekst[::-1]

if tekst == tekst_odwrócony:
    print("Wpisany tekst jest palindronem.")

elif tekst != tekst_odwrócony:
    print("Wpisany tekst nie jest palindromem.")

print(f'Wpisany tekst:  {tekst}')
print(f'Odwrócony tekst:  {tekst_odwrócony}')

'''
'''
lista =[15, 16, 20, 24, 30]

if any([i % 2 == 0 for i in lista]):
    print("Wszystkie liczby na liście są parzyste")
else:
    print("Nie wszystkie liczby są parzyste.")    


for i in enumerate(lista):
    print(i)

'''
'''
# Program liczy ile liter alfabetu jest w tekscie i prezentuje je w formie procentowej

plik = open("covid.txt", "r")

tekst = plik.read()

plik.close()

def policz(txt, znak):
    licznik = 0
    for z in txt:
        if z == znak:
            licznik = licznik + 1
    return licznik


print(policz(tekst, "A"))

for z in "aąbcćdeęfghijklłmnoóprsśtuwxyzżź ":
    ile = policz(tekst.lower(), z)
    procent = 100 * ile / len(tekst)
    print("{0} - {1} - {2} %".format(z.upper(), ile, round(procent, 2)))


# Program tworzy listę liczb parzystych [b] z listy [a]
'''

'''
a = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
b = []


for liczba in a:
    if liczba % 2 == 0:
        b.append(liczba)
print(b)    


b = ([liczba for liczba in a if liczba % 2 == 0])



print(b)    
'''

# Gra papier kamień nożyce 
'''
wybór = -1
decyzja = "gogo"
while wybór != 2:
    print()
    print()
    print()
    print("1. Zagraj w grę papier, kamień, nożyce")
    print("2. Wyjście z gry")
    wybór = int(input("Wybierz grę lub wyjście z gry:  "))
    if wybór == 1:
        while decyzja != "nie":


            wybór_gracza_1 = input("Graczu 1 podaj swój wybór ( papier, kamień, nożyce) ")

            wybór_gracza_2 = input("Graczu 2 podaj swój wybór ( papier, kamień, nożyce) ")

            print(f'Gracz pierwszy wybrał  {wybór_gracza_1} ')
            print(f'Gracz drugi wybrał  {wybór_gracza_2} ')
            if wybór_gracza_1 == "kamień" and wybór_gracza_2 == "nożyce":
                print(f'Wygrał gracz pierwszy ponieważ {wybór_gracza_1} pokonuje {wybór_gracza_2}')
            elif wybór_gracza_1 == "nożyce" and wybór_gracza_2 == "papier":
                print(f'Wygrał gracz pierwszy ponieważ {wybór_gracza_1} pokonuje {wybór_gracza_2}')
            elif wybór_gracza_1 == "papier" and wybór_gracza_2 == "kamień":
                print(f'Wygrał gracz pierwszy ponieważ {wybór_gracza_1} pokonuje {wybór_gracza_2}')
            elif wybór_gracza_2 == "kamień" and wybór_gracza_1 == "nożyce":
                print(f'Wygrał gracz drugi ponieważ {wybór_gracza_2} pokonuje {wybór_gracza_1}')
            elif wybór_gracza_2 == "nożyce" and wybór_gracza_1 == "papier":
                print(f'Wygrał gracz drugi ponieważ {wybór_gracza_2} pokonuje {wybór_gracza_1}')
            elif wybór_gracza_2 == "papier" and wybór_gracza_1 == "kamień":
                print(f'Wygrał gracz drugi ponieważ {wybór_gracza_2} pokonuje {wybór_gracza_1}')
            elif wybór_gracza_1 == wybór_gracza_2:
                print("REMIS :))")    
            decyzja = input("Czy chcesz zagrać jeszcze raz?? tak / nie  ")
            
                


    elif wybór == 2:
        print()
        print()
        print()
        print("Wybrałeś wyjście z gry")
        break
'''

# gra zgadnij liczbę 1 - 9
'''
import random
from random import randint

losowa = random.randint(1,50)
liczba = -1
licznik = 0

while liczba != losowa:


    liczba = int(input("Podaj liczbę:  "))

    licznik = licznik + 1

    if liczba > losowa:
        print()
        print()
        print()
        print("Podałeś liczbę większą niż wylosowana liczba. ")
    elif liczba == losowa:
        print()
        print()
        print("Podana liczba jest taka sama jak wylosowana liczba.")
    else:
        print()
        print()
        print("Podana liczba jest mniejsza niż wylosowana liczba.")    


    #print(f'Podana liczba to:  {liczba}')
    #print(f'Wylosowana liczba to: {losowa}')

print(f'Zgadłeś za {licznik} razem. gratulacje :)')
'''

# Ćwiczenie 12 Napisz program, który pobiera listę liczb (na przykład a = [5, 10, 15, 20, 25]) 
# i tworzy nową listę tylko z pierwszego i ostatniego elementu podanej listy. Aby poćwiczyć, napisz ten kod wewnątrz funkcji.
'''
a = [5, 10, 15, 20, 25]

b = []
b.append(a[0])
b.append(a[len(a)-1])



print(a)
print(b)
'''

lista_a = [5, 10, 15, 20, 25]
lista_b = []

def pierwszy_i_ostatni_element():
    lista_b.append(lista_a[0])
    lista_b.append(lista_a[len(lista_a)-1])
    print(f'Funkcja drukuje listę b {lista_b}')


pierwszy_i_ostatni_element()    