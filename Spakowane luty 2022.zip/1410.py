from random import randint, random
import random
# To jest gra tekstowa pt. 1410 :)

# Mooby -    HP, atak, obrona, level

klasa_postaci = 'Rycerz'
level_postaci = 1
hp_postaci = 300

atak_postaci = 20
obrona_postaci = 15
zwinność_postaci = 5

punkty_doświadczenia = 0
ilość_złota = 50


ilość_potek_50_HP = 2
ilość_potek_70_HP = 2
ilość_potek_100_HP = 0
ilość_eliksirów_200_HP = 1
ilość_eliksirów_500_HP = 0


wiewiórka = (40, 6, 5, 1)
szczur = (80, 12, 10, 2)
jeleń = (320, 50, 45, 6)
ryś = (700, 100, 85, 9)
niedźwiedź = (1400, 300, 250, 12)


hp_wiewiórki = wiewiórka[0]
atak_wiewiórki = wiewiórka[1]
obrona_wiewiórki = wiewiórka[2]
level_wiewiórki = wiewiórka[3]

hp_szczura = szczur[0]
atak_szczura = szczur[1]
obrona_szczura = szczur[2]
level_szczura = szczur[3]

hp_jelenia = jeleń[0]
atak_jelenia = jeleń[1]
obrona_jelenia = jeleń[2]
level_jelenia = jeleń[3]


# Funkcja pokazująca jaki level ma postać
def jaki_jest_level_postaci(punkty_doświadczenia):

    if punkty_doświadczenia < 101:
        return 1
    elif punkty_doświadczenia < 251:
        return 2
    elif punkty_doświadczenia < 451:
        return 3
    elif punkty_doświadczenia < 731:
        return 4
    elif punkty_doświadczenia < 1131:
        return 5
    elif punkty_doświadczenia < 1701:
        return 6
    elif punkty_doświadczenia < 2601:
        return 7
    elif punkty_doświadczenia < 3801:
        return 8
    elif punkty_doświadczenia < 5801:
        return 9
    elif punkty_doświadczenia >= 5801:
        return 10


#level_postaci = jaki_jest_level_postaci(punkty_doświadczenia)

# Funkcja określa jaki jest atak postaci powiązany z levelem, bez eq.


def jaki_jest_atak_postaci(level_postaci):
    if level_postaci == 1:
        return 20
    elif level_postaci == 2:
        return 30
    elif level_postaci == 3:
        return 40
    elif level_postaci == 4:
        return 50
    elif level_postaci == 5:
        return 60
    elif level_postaci == 6:
        return 70
    elif level_postaci == 7:
        return 80
    elif level_postaci == 8:
        return 90
    elif level_postaci == 9:
        return 100
    elif level_postaci == 10:
        return 110
    elif level_postaci == 11:
        return 120
    else:
        return 150


#atak_postaci = jaki_jest_atak_postaci(level_postaci)

# Funkcja określająca max hp postaci bez eq


def max_hp_postaci_bez_eq(level_postaci):
    if level_postaci == 1:
        return 300
    elif level_postaci == 2:
        return 350
    elif level_postaci == 3:
        return 400
    elif level_postaci == 4:
        return 450
    elif level_postaci == 5:
        return 500
    elif level_postaci == 6:
        return 550
    elif level_postaci == 7:
        return 600
    elif level_postaci == 8:
        return 650
    elif level_postaci == 9:
        return 700
    elif level_postaci == 10:
        return 750
    elif level_postaci == 11:
        return 800


max_hp_postaci_bez_equ = max_hp_postaci_bez_eq(level_postaci)


# Funkcja wyświetlająca statystyki postaci.
def statystyki_postaci():
    print()
    print(
        "            -------------------------------------------------------------------------------")
    print()
    print(f'            Klasa postaci: {klasa_postaci};  Level postaci: {level_postaci}; HP postaci: {hp_postaci}; Max HP bez eq: {max_hp_postaci_bez_equ} Atak postaci: {atak_postaci} PKT; Punkty doświadczenia: {punkty_doświadczenia} ')
    print(
        f'            Obrona postaci: {obrona_postaci};  Zwinność postaci: {zwinność_postaci}; Ilość złota: {ilość_złota}; ')
    print()
    print(
        "            -------------------------------------------------------------------------------")
    print()
    print()
    print()


wybor_usera = -1

while wybor_usera != 8:

    print("1. Wczytaj grę")
    print("2. Zapisz grę")
    print("3. Plecak")
    print("4. Umiejętności")
    print("5. EXP")
    print("6. Trening")
    print("7. Zakupy")
    print("8. Wyjście z gry")
    print("9. Wyświetl statystyki postaci")

    wybor_usera = int(input("Jesteś w menu głównym. Wybierz działanie (1 - 9): "))
    if wybor_usera == 1:
        plik = open("statystyki.txt", "r+")


    elif wybor_usera == 2:
        print()
        print("Gra będzie zapisana ale narazie nie wiem jak ...")
        print()

    elif wybor_usera == 3:
        print()
        print()
        print(
            "Będzie wyświetlona zawartość plecaka, też narazie nie wiem jak :( ...")
        print("Wyświetli listę rzeczy jakie mam w plecaku, ich ilość, wartość staty itp,Będzie można sprzedać od razu item i wyświetli zaktualizowaną listę rzeczy")
        print()
        print()

    elif wybor_usera == 4:
        print()
        print(
            "Jesteś w menu Umiejętności .. nie mam pojęcia co tu będzie ale coś będzie ...")
        print("Mogę tu wyświetlić np punkty otrzymywane za zadawanie ciosów np mieczem, obuchem, toporem, np ciosy mieczem Lv 1: 55/100")
        print()

    elif wybor_usera == 5:
        print()
        print("Jesteś w menu ekspienia. Jakiego moba chcesz uderzyć? ")
        print()

        while wybor_usera != 7:

            print("1. Atakuj wiewiórkę")
            print("2. Atakuj szczura")
            print("3. Atakuj jelenia")
            print("4. Atakuj rysia")
            print("5. Atakuj niedźwiedzia")
            print("6. Wypij lekarstwo")
            print("7. Wyjście")

            wybor_usera = int(input(
                "Wybierz walkę z mobem (1 - 5) Łyknij potkę - 6 albo wyjdź do menu głównego - 7:  "))
            if wybor_usera == 1:
                print()
                print()
                print()
                print()
                print()
                print("Wybrałeś walkę z wiewiórką ")
                print()

                # Pętla while tu będzie aby zautomatyzować klikanie i drop trzeba ogarnąć to przyspieszy dalszą prace
                # Walka z wiewiórką
                while hp_wiewiórki > 0:

                        
                    dmg_postaci = int((atak_postaci/obrona_wiewiórki)*4)
                    print(f'dmg_postaci: {dmg_postaci}')
                    dmg_wiewiórki = int((atak_wiewiórki/obrona_postaci)*15)
                    print(f'dmg_wiewiórki: {dmg_wiewiórki}')
                    hp_postaci = hp_postaci - dmg_wiewiórki
                    print(f'hp_postaci: {hp_postaci}')
                    hp_wiewiórki = hp_wiewiórki - dmg_postaci
                    print(f'hp_wiewiórki: {hp_wiewiórki}')

                punkty_doświadczenia = punkty_doświadczenia + wiewiórka[0]
                wydropione_złoto = randint(5, 15)
                ilość_złota = ilość_złota + wydropione_złoto
                

                # Drop z moba napisać ... ?? Co może dropić? skóra, mięso, krew, złoto, eq rzadko, potki rzadko
                level_postaci = jaki_jest_level_postaci(punkty_doświadczenia)
                max_hp_postaci_bez_equ = max_hp_postaci_bez_eq(level_postaci)
                atak_postaci = jaki_jest_atak_postaci(level_postaci)

                print()
                print()
                print()
                print(f'Wiewiórka nie żyje :(( HP postaci wynosi {hp_postaci}')
                print(f'Dropnęło {wydropione_złoto} złota z mobka :) ')
                print(f'Punkty doświadczenia EXP:  {punkty_doświadczenia}')
                print(f'Level Twojej postaci: {level_postaci}')
                hp_wiewiórki = 40

            elif wybor_usera == 2:
                print()
                print()
                print()
                print()
                print()
                print("Wybrałeś walkę ze szczurem ")
                print()

                if hp_szczura > 0:

                    dmg_postaci = int((atak_postaci/obrona_szczura)*4)
                    dmg_szczura = int((atak_szczura/obrona_postaci)*15)
                    hp_postaci = hp_postaci - dmg_szczura
                    hp_szczura = hp_szczura - dmg_postaci

                    print(f'Hp szczura po ataku postaci wynosi: {hp_szczura}')
                    print(f'Hp postaci po ataku szczura wynosi: {hp_postaci}')

                    if hp_szczura <= 0:
                        print()
                        print()
                        print()
                        print()
                        print()
                        print(
                            f'Szczur nie żyje :(( HP postaci wynosi {hp_postaci}')
                        print()
                        print()
                    # break
                else:
                    print()
                    print()
                    print()
                    print()
                    print()
                    print(f'Szczur nie żyje. HP postaci wynosi {hp_postaci} ')
                    print()

            elif wybor_usera == 3:
                print()
                print()
                print()
                print()
                print()
                print("Wybrałeś walkę z jeleniem. ")
                print()

                if hp_jelenia > 0:

                    dmg_postaci = int((atak_postaci/obrona_jelenia)*4)
                    dmg_jelenia = int((atak_jelenia/obrona_postaci)*15)
                    hp_postaci = hp_postaci - dmg_jelenia
                    hp_jelenia = hp_jelenia - dmg_postaci

                    print(f'Hp jelenia po ataku postaci wynosi: {hp_jelenia}')
                    print(f'Hp postaci po ataku jelenia wynosi: {hp_postaci}')

                    if hp_jelenia <= 0:
                        print()
                        print()
                        print()
                        print()
                        print()
                        print(
                            f'Jeleń nie żyje :(( HP postaci wynosi {hp_postaci}')
                        print()
                        print()
                    # break
                else:
                    print()
                    print()
                    print()
                    print()
                    print()
                    print(f'Jeleń nie żyje. HP postaci wynosi {hp_postaci} ')
                    print()

            elif wybor_usera == 4:
                print()
                print("Wybrałeś walkę z rysiem. ")
                print()

            elif wybor_usera == 5:
                print()
                print("Wybrałeś walkę z niedźwiedziem. ")
                print()

            elif wybor_usera == 6:
                print()
                max_hp_postaci_bez_eq(level_postaci)

                print("Wybrałeś wypicie lekarstwa: ")
                print("Jakie lekarstwo chcesz wypić? ")
                print(
                    f'1. Miksturę leczącą + 50 HP? Masz {ilość_potek_50_HP} sztuk')
                print(
                    f'2. Miksturę leczącą + 70 HP? Masz {ilość_potek_70_HP} sztuk')
                print(
                    f'3. Miksturę leczącą + 100 HP? Masz {ilość_potek_100_HP} sztuk')
                print(
                    f'4. Eliksir leczący + 200 HP? Masz {ilość_eliksirów_200_HP} sztuk')
                print(
                    f'5. Eliksir leczący + 500 HP? Masz {ilość_eliksirów_500_HP} sztuk')

                wybor_usera = int(input("Wybierz lekarstwo (1 - 5) "))

                # hp nie może być większe niż hp maksymalne tzn ze jezeli hp max wynosi 300 to po przyjeciu potki hp nie może być większe niż 300
                # jesli hp wynosi np 290 i po potce +20 hp nie może być 310 hp tylko 300 hp czyli hp maksymalne

                if wybor_usera == 1:
                    if ilość_potek_50_HP > 0:
                        if hp_postaci < max_hp_postaci_bez_equ:

                            hp_postaci = hp_postaci + 50
                            ilość_potek_50_HP = ilość_potek_50_HP - 1

                            if hp_postaci > max_hp_postaci_bez_equ:

                                hp_postaci = max_hp_postaci_bez_equ

                        elif hp_postaci > max_hp_postaci_bez_equ:

                            hp_postaci = max_hp_postaci_bez_equ

                    else:
                        print("Nie masz już potek + 50 HP")

                if wybor_usera == 2:
                    if ilość_potek_70_HP > 0:
                        if hp_postaci < max_hp_postaci_bez_equ:

                            hp_postaci = hp_postaci + 70
                            ilość_potek_70_HP = ilość_potek_70_HP - 1

                            if hp_postaci > max_hp_postaci_bez_equ:

                                hp_postaci = max_hp_postaci_bez_equ

                        elif hp_postaci > max_hp_postaci_bez_equ:

                            hp_postaci = max_hp_postaci_bez_equ

                    else:
                        print("Nie masz już potek + 70 HP")

                print(f'HP postaci wynosi: {hp_postaci} punktów')
                print()

            elif wybor_usera == 7:
                print()
                print("Wybrałeś wyjście do menu głównego. ")
                print()
                break

    elif wybor_usera == 6:
        print()
        print("Jesteś w menu trening. Co chcesz trenować? ")
        print()

    elif wybor_usera == 7:
        print()
        print("Jesteś w menu Zakupy. Co chcesz kupić? ")
        print()

    elif wybor_usera == 8:
        print()
        print("Wychodzisz z gry. Czy chcesz zapisać stan gry? ")

        klasa_postaci_str = str(klasa_postaci)

        level_postaci_str = str(level_postaci)
        hp_postaci_str = str(hp_postaci)
        max_hp_postaci_bez_equ_str = str(max_hp_postaci_bez_equ)

        atak_postaci_str = str(atak_postaci)
        obrona_postaci_str = str(obrona_postaci)
        zwinność_postaci_str = str(zwinność_postaci)

        punkty_doświadczenia_str = str(punkty_doświadczenia)

        ilość_złota_str = str(ilość_złota)

        plik.write(klasa_postaci_str + "\n" + level_postaci_str + "\n" + hp_postaci_str + "\n" + max_hp_postaci_bez_equ_str + "\n" + atak_postaci_str + "\n" +
                   obrona_postaci_str + "\n" + zwinność_postaci_str + "\n" + punkty_doświadczenia_str + "\n" + ilość_złota_str + "\n" + "0")

        plik.close()
        print()
        break

    elif wybor_usera == 9:
        print()
        print()
        print()
        statystyki_postaci()
        print()
        print()
        print()
        print()


# Ogarnąć hp postaci bo nie może być rowne 0 lub ujemne  if hp_postaci =< 0:  Bauron nie żyje :(
    # Ogarnąć zabezpieczenia jeśli ktoś wpisuje głupoty np, w menu wyboru wpisze ujemną lub za dużą liczbę, stringa, spację lub entera
    # Ogarnąć drop eq oraz itemów z mobów, będzie to trudne
    # Ogarnąć plecak bo itemy muszą być w plecaku
    # Czas ukończenia kodu gry - początek marca 2022
