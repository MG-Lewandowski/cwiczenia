'''
ilosc_kart = 24
liczba_graczy = 4

liczba_dziewiatek = 4
liczba_dziesiatek = 4
liczba_waletow = 4
liczba_dam = 4
liczba_kroli = 4
liczba_asow = 4
'''

karty_informacje = {}

karty_informacje["9_pik"] = ("Dziewiatka Pik", 9, 1, "Czarny")
karty_informacje["10_pik"] = ("Dziesiatka Pik", 10, 2, "Czarny")
karty_informacje["Walet_Trefl"] = ("Walet Trefl", 11, 3, "Czarny")
karty_informacje["Dama_Karo"] = ("Dama Karo", 12, 4, "Czerwony")



    
for karty in karty_informacje.keys():
    print(karty)

karty = input("Wybierz karte :")

informacja_o_karcie = karty_informacje.get(karty)




print()
print(karty)
print("----------")
print("Nazwa karty to: " + informacja_o_karcie[0])
print("Moc karty: " + str(informacja_o_karcie[1]))
print("Punkty przypadajace na karte: " + str(informacja_o_karcie[2]))
print("Kolor karty: " + informacja_o_karcie[3])
print()
print("----------")
print()
print()
