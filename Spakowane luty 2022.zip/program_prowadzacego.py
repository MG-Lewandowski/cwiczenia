ci = {}
ci["Polska"] = ("Warszawa", 37.97)
ci["Niemcy"] = ("Berlin", 83.02)
ci["Słowacja"] = ("Bratyslawa", 5.45)


def show_country_info(country):
    coi = ci.get(country)

    print()
    print(country)
    print("--------")
    print("Stolica: " + coi[0])
    print("Liczba mieszkancow (mln): " + str(coi[1]))


for country in ci.keys():
    print(country)

country = input("Informacje o jakim kraju chcesz wyswietlic? ")
show_country_info(country)
