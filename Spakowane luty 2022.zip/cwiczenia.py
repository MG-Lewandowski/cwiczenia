wartość_float = 0


def computegrade(wartość_float):
    try:
        wartość_float = float(input("Podaj wartość pomiędzy 0.0 a 1.0:  "))
        print(wartość_float)
        if wartość_float >= 0 and wartość_float <= 1:
            if wartość_float >= 0.9:
                print("Wartość      Ocena")
                print(f'  {wartość_float}       5,0')
            elif wartość_float >= 0.8:
                print("Wartość      Ocena")
                print(f'  {wartość_float}       4,5')
            elif wartość_float >= 0.7:
                print("Wartość      Ocena")
                print(f'  {wartość_float}       4,0')

            elif wartość_float >= 0.6:
                print("Wartość      Ocena")
                print(f'  {wartość_float}       3,5')   
            elif wartość_float >= 0.5:
                print("Wartość      Ocena")
                print(f'  {wartość_float}       3,0')
            elif wartość_float < 0.5:
                print("Wartość      Ocena")
                print(f'  {wartość_float}       2,0')
        else:
            print("Niepoprawna wartość . . .")


    except:

        print("Niepoprawna wartość . . .")


computegrade(wartość_float)

#  przyjmuje jako argument  wartość i zwraca ocenę jako ciąg znaków.