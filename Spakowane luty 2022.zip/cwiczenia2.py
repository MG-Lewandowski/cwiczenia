# Proste menu - zabezpieczenie przed wpisaniem stringa lub innej cyfry
inp = -1

while inp != 4:
        

            print()
            print()
            print("1. Odczyt / zapis")
            print("2. Start gry")
            print("3. Przygody")
            print("4. Wyjście")
            print()
            print()
            inp = input("Wybierz pozycję z menu: 1 - 4  ")
            try:
                wybór = int(inp)

                if wybór == 1:
                    print()
                    print()
                    print("Jesteś w menu odczyt / zapis")
                    print()
                    print()
                    print("1. Wczytaj grę  ")
                    print("2. Zapisz grę  ")
                    print("3. Wyjdź do menu głównego")
                    inp = input("Wybierz pozycję z menu: 1 - 4  ")
                        
                    wybór = int(inp)

                    if wybór == 1:
                                print()
                                print()
                                print("Gra została wczytana . . .")
                                print()
                                print()
                    elif wybór == 2:
                                print()
                                print()
                                print("Gra została zapisana . . .")
                                print()
                                print()
                    elif wybór == 3:
                                print()
                                print()
                                print("Wybrałeś wyjście do menu głównego . . .")
                                print()
                                print()
                        
                    elif wybór > 4:
                        print()
                        print()
                        print("Podałeś za dużą liczbę: ") 

                    else:
                        print()
                        print()
                        print("Błąd - wpisałeś stringa. Podaj jeszcze raz wartość z menu: ")        

                elif wybór == 2:
                    print()
                    print()
                    print("Jesteś w menu Start gry")
                    print()
                    print()

                elif wybór == 3:
                    print()
                    print()
                    print("Jesteś w menu Przygody")
                    print()
                    print()

                elif wybór == 4:
                    print()
                    print()
                    print("Jesteś w menu wyjście")
                    print()
                    print()  
                    break
                elif wybór > 4:
                    print()
                    print()
                    print("Podałeś za dużą liczbę: ")
                            
            except:
                print()
                print()
                print("Błąd - wpisałeś stringa. Podaj jeszcze raz wartość z menu: ")
