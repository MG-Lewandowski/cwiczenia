for number in range(0, 10):
    if number == 5:
        break
    print(number)
    print(number)