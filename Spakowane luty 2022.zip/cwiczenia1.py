import random, math


for i in range(10):
    x = random.random()
    print(x)


def print_lyrics():
    print("Jestem sobie drwal i równy chłop.")
    print('Pracuję w dzień i śpię całą noc.')

print_lyrics()


u = int(math.pow(2, 36))

print(u)

def print_twice(bruce):

    print(bruce)
    print(bruce)


print_twice(12)
michael = 'Eryk Pół-Ćma.'
print_twice(michael)

def addtwo(a, b):
    added = a + b
    return added

x = addtwo(3, 5)
print(x)

def fred():
    print("Zap")   
def jane():
    print("ABC")
jane()
fred()
jane()

n = 10

while n > 0:
    n = n - 1
    print(n)
    
    
print("Odpalamy :) ")