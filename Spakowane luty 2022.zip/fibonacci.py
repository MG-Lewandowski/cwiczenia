# Program podaje tyle liczb z ciągu Fibonacciego ile zarzyczy sobie urzytkownik/ zrobić to we funkcji
'''
a = 1

fibo = [0, 1]


ile_liczb_wygenerować = int(input("Ile liczb ciągu Fibonacciego wygenerować?  "))

while a != ile_liczb_wygenerować - 1:
    liczba = fibo[a] + fibo[a-1]
    #print(liczba)




    a = a + 1
    fibo.append(liczba)

print(fibo)   
'''


# Zaczynam pisać funkcję

#a = 1
fibo = [0, 1]

ile_liczb_wygenerować = int(input("Ile liczb ciągu Fibonacciego wygenerować?  "))


def fibonacci(ile_liczb_wygenerować):
    a = 1
    while a != ile_liczb_wygenerować - 1:
        liczba = fibo[a] + fibo[a-1]
        a = a + 1
        fibo.append(liczba)
    print(fibo)

    
fibonacci(ile_liczb_wygenerować)        