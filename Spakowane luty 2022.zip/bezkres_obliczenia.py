#Monety Baurona
złota_korona_ilość = 12
złoty_denar_ilość = 24
złoty_cetnar_ilość = 5

srebrna_korona_ilość = 50
srebrny_cetnar_ilość = 75
srebrzysty_wilk_ilość = 15

miedziana_tarcza_ilość = 3
miedziany_żubr_ilość = 30

# złoto_baurona_ilość = 12000

złota_korona_wartość = 3600
złoty_denar_wartość = 1200
złoty_cetnar_wartość = 600

srebrna_korona_wartość = 300
srebrny_cetnar_wartość = 150
srebrzysty_wilk_wartość = 50

miedziana_tarcza_wartość = 5
miedziany_żubr_wartość = 1

# Ceny towarów

cena_kurczaka_cena = 30
młot_kowalski_cena = 250
noc_w_burdelu = 1000

wartość_monet_baurona =(złota_korona_ilość * złota_korona_wartość) + (złoty_denar_ilość * złoty_denar_wartość) + (złoty_cetnar_ilość * złoty_cetnar_wartość) + (srebrna_korona_ilość * srebrna_korona_wartość) + (srebrny_cetnar_ilość * srebrny_cetnar_wartość) + (srebrzysty_wilk_ilość * srebrzysty_wilk_wartość) + (miedziana_tarcza_ilość * miedziana_tarcza_wartość) + (miedziany_żubr_ilość * miedziany_żubr_wartość)
print(wartość_monet_baurona)

# Bauron kupuje młot kowalski

młot_kowalski_cena = srebrny_cetnar_ilość + (2 * srebrzysty_wilk_ilość)

from random import randint


# Najpierw zakres potem ile liczb ma wygenerować
# x = [randint(0, 3) for p in range(0, 10)]

kurs = 1

for liczba in range(1, 67):


    x = randint(0, 3)
    print(x)
    if x <= 2:
        kurs = kurs +1

    else:
        kurs = kurs -1


print("Kurs wynosi: " + str(kurs))


max = 0

for i in [3, 41, 12, 9, 74, 15]:

    if i > max:
        max = i
    print(f'Aktualna liczba wynosi {i}')
    print(f'Maksymalna liczba wynosi: {max}')
print()
print(f'Maksymalna wartość wynosi:  {max}')