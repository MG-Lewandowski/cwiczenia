dzielnik = 0
czysiedzieli = 0
zakres = 0



zakres = int(input("Wpisz zakres np 100: "))
print()
print("-----------")

dzielnik = int(input("Podaj dzielnik: "))
print()
print("-----------")



for liczby in range(1, zakres):
    
    a = liczby%dzielnik
    print("Zakres wynosi: " + str(zakres) + "  Liczba do podzielenia to: " + str(liczby) + "  Dzielnik wynosi: " + str(dzielnik) + "  a reszta z dzielenia to: " + str(a))
    if a == 0:
        print("Huj Ci w dupe !!!")

for liczby in range(1, zakres):
    x = zakres/liczby

    if zakres%liczby == 0:
        czysiedzieli = czysiedzieli + 1

    print("Zakres: " + str(zakres) + " dzielony przez " + str(liczby) + " wynosi " + str(x))