a = 7
b = 17

print (a+b)
print (a-b)
print (a*b)
print (a/b)
print (b%a)

if a > b:
    
    print("a jest większe od b")
else:
    print("B jest wieksze od a")
    
wiek = int(input("Podaj swój wiek: "))

if wiek > 60:
    print("O kurwa")



elif wiek <=60 and wiek >16:   

    print("Jesteś stara dupa hehe.")
else:
    
    print("Idziemy na spacer") 