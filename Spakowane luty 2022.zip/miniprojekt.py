import math

wybór = -1
a = 0

while wybór != 2:
    print("1. Podaj liczbę do potęgowania i pierwiastkowania: ")
    print("2. Zakończ obliczenia")

    wybór = int(input("Wpisz 1 lub 2 aby kontynuować: "))
    if wybór == 1:
        a = int(input("Podaj liczbę: "))
        wynikmnozenia = a*a
        wynikpierwiastkowania = math.sqrt(a) 

        print(wynikmnozenia)
        print(wynikpierwiastkowania)
