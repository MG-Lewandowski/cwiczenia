karty_informacje = {}

karty_informacje["9_pik"] = ("Dziewiatka Pik", 9, 1, "Czarny")
karty_informacje["10_pik"] = ("Dziesiatka Pik", 10, 2, "Czarny")
karty_informacje["Walet_Trefl"] = ("Walet Trefl", 11, 3, "Czarny")
karty_informacje["Dama_Karo"] = ("Dama Karo", 12, 4, "Czerwony")

# Definiuję fukcje
def pokaz_informacje_o_kartach(karty):
    informacja_o_karcie1 = karty_informacje.get(karty)


    print()
    print(karty)
    print("----------")
    print("Nazwa karty to: " + informacja_o_karcie1[0])
    print("Moc karty: " + str(informacja_o_karcie1[1]))
    print("Punkty przypadajace na karte: " + str(informacja_o_karcie1[2]))
    print("Kolor karty: " + informacja_o_karcie1[3])
    print()
    print("----------")
    print()
    print()

for karty in karty_informacje.keys():
    print(karty)


karty = input("Wybierz karte :")
pokaz_informacje_o_kartach(karty)