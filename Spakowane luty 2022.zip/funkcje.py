a = 4
b = 5
i = 10 

 

for x in range(30):
  print("Wynik = " + str(x*a-i))
  if (x*a-i) > 60:
      print("Za duzo naliczone mordo !!!")
