#program, który prosi użytkownika o podanie swojego imienia i wieku. Wydrukuj wiadomość zaadresowaną do nich, która mówi im rok, w którym skończą 100 lat.
from random import randint
import random

'''
imie = input("Podaj imie: ")
wiek = int(input("Ile masz lat? "))

kiedy_stówa = 2022 - wiek + 100



print("Witaj " + imie)
print(f'Osiągniesz 100 lat w roku  {kiedy_stówa}')

# Program sprawdza czy liczba jest parzysta czy nieparzysta i sprawdza czy jest podzielna przez 4


liczba_do_sprawdzenia = int(input("Podaj liczbę do sprawdzenia:  "))

try:


    if (liczba_do_sprawdzenia % 4) == 0:
        print(f'Podana liczba  {liczba_do_sprawdzenia} jest podzielna przez 4 i 2')

    elif (liczba_do_sprawdzenia % 2) == 0:
        print(f'Podana liczba  {liczba_do_sprawdzenia} jest podzielna  przez 2')   

    else:
        print(f'Podana liczba  {liczba_do_sprawdzenia} jest nieparzysta')  

except:
    print(f'Podaj liczbę:  ') 



a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

nowa_lista = []
i = 0


for elementy in a:
    if elementy < 5:
        nowa_lista.append(elementy)

        #print(elementy)
print(a)        
print(nowa_lista)






a = 1

fibo = [0, 1]

while a != 12:
    liczba = fibo[a] + fibo[a-1]
    #print(liczba)




    a = a + 1
    fibo.append(liczba)

print(fibo)    
'''



# Utwórz program, który prosi użytkownika o liczbę, a następnie wyświetla listę wszystkich dzielników tej liczby.

'''
liczba = int(input("Wprowadź liczbę:  "))

kolejny_dzielnik = 1

lista_dzielników = []

while kolejny_dzielnik <= liczba:
    if liczba % kolejny_dzielnik == 0:
        lista_dzielników.append(kolejny_dzielnik)
        kolejny_dzielnik = kolejny_dzielnik + 1
    elif liczba % kolejny_dzielnik != 0:
        
        kolejny_dzielnik = kolejny_dzielnik + 1


print(f' Dzielniki liczby  {liczba}  to {lista_dzielników} ')
'''

# program, który zwróci listę zawierającą tylko te elementy, które są wspólne dla list (bez duplikatów). Upewnij się, że Twój program działa na dwóch listach o różnych rozmiarach



'''
for i in a:
    for i in b:
        #if a[i] > b[j]:
            #print("Znalazłem tą samą liczbę  ")
        print([i for i in a if i in b])
        c.append([i for i in a if i in b])
        print(c)
'''          



'''


a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
b = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]

c = []
print()
print()
print()
print()
print()
print()
print()
print()
print()
print()
print()
#print([i for i in a if i in b])
#c.append([i for i in a if i in b])
#print(c)

for i in a:

    if i in b:
        c.append(i)

#print(c)   
c.sort()
print(c) 
'''

'''
# Generowanie listy list macierzy
macierz = []
macierz1 = []
a = 0

while a < 10:

    l = [random.randint(0,3) for i in range(8)] # Generowanie jednej lini w macierzy
    a = a + 1
    macierz.append(l)   # Dodawanie wygenerowanej lini / listy do macierzy głównej

print()
print()
print()

print()
print()
print()

for kolumny in macierz:   # Drukowanie macierzy jako osobne wiersze i kolumny itp itd ...
    print(kolumny)



for i in range(len(macierz)):
    for j in range(len(macierz[i])):
        macierz[i][j] = macierz[i][j] + 1
        print(macierz[i][j], end="  ")
    print() 
'''



'''

for kolumny in macierz:
    for element in kolumny:
        
        print(element, end=" ")
    print()   
'''

   