
bauron_hp = 14000
bauron_rec = 600
bauron_atk = 1200
bauron_obrazenia = 0


woj_hp = 13000
woj_rec = 550
woj_atk = 1100
woj_obrazenia = 0

bauron_dmg = (bauron_atk/woj_rec)*1000
woj_dmg = (woj_atk/bauron_rec)*1000

print("Bauron bije woja po: " + str(bauron_dmg))
print("Woj bije Baurona po: " + str(woj_dmg))
print()
print("--------")


while bauron_hp and woj_hp > 0:
    

    if bauron_hp or woj_hp > 0:

        bauron_hp = bauron_hp - woj_dmg
        woj_hp = woj_hp - bauron_dmg

        print("HP Baurona wynosi: " + str(bauron_hp))
        print("HP woja wynosi: " + str(woj_hp))

        if bauron_hp < 0:
            print("Bauron nie żyje")
            break

        if woj_hp < 0:
            print("Wojak nie żyje")    
            break
        
    