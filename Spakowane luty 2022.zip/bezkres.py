# To jest gra tekstowa. BEZKRES :)

# Zmienne globalne

level = 1
witalność = 60
wydolność = 15
udźwig = 16

ilość_piwa = 0

#Monety
złota_korona = 12
złoty_denar = 24
złoty_cetnar = 5

srebrna_korona = 50
srebrny_cetnar = 75
srebrzysty_wilk = 15

miedziana_tarcza = 3
miedziany_żubr = 30

złoto_baurona = 12000

#Ceny

Kurczak = 6 * miedziana_tarcza
Worek_ziemniaków_5kg = 4 * miedziana_tarcza
Marchew_2kg = 0
piwo = 2 

# Bauron kupuje 2 piwa
print()
print(f'Piwo kosztuje {piwo} sztuk złota.')
print("Bauron kupuje 2 piwa")
print(f'Przed zakupami Bauron ma {ilość_piwa} piwa oraz {złoto_baurona} złota.')

ilość_piwa = ilość_piwa + 2
złoto_baurona = złoto_baurona - (2 * piwo)
print()
print(f'Po zakupach Bauron ma {ilość_piwa} piwa oraz {złoto_baurona} złota.')



print()
print("-------------------------------------------")
print("   To jest gra przygodowa p.t.  Bezkres    ")
print("-------------------------------------------")
print()

wybor_usera = -1

while wybor_usera != 10:


    print("1. Wczytaj grę")
    print("2. Zapisz grę")
    print("3. Ekwipunek")
    print("4. Umiejętności")
    print("5. Zadania")
    print("6. Trening")
    print("7. Odpoczynek")
    print("8. Finanse")
    print("9. Mapa")
    print("10. Zakończ grę")

    wybor_usera = int(input("Jesteś w menu głównym. Wybierz działanie (1 - 10): "))
    if wybor_usera == 1:
        print()
        print("Gra zostanie wczytana ")
        print()

    elif wybor_usera == 2:
        print()
        print("Gra zostanie zapisana ")
        print()

    elif wybor_usera == 3:
        print()
        print("Wyświetlam ekwipunek: ")
        print()

    elif wybor_usera == 4:
        print()
        print("Moje umiejętności ... ")
        print()

    elif wybor_usera == 5:
        print()
        print("Zadania do wykonania ... ") 
        print()

    elif wybor_usera == 6:
        print()
        print("1. Trening siłowy ... ")
        print("2. Trening rzemieślniczy ... ")
        print("3. Trening inny (jaki??) ... ")
        print()

    elif wybor_usera == 7:
        print()
        print("Regeneracja pomoże Ci odzyskać siły oraz zwiększyć level trenowanych umiejętności ... ")
        print()

    elif wybor_usera == 8:
        print()
        print("Finanse: ")
        print(f'Posiadasz {złota_korona} złotych koron, {złoty_denar} złotych denarów, {złoty_cetnar} złotych cetnarów.')
        print(f'Posiadasz {srebrna_korona} srebrnych koron, {srebrny_cetnar} srebrnych cetnarów, {srebrzysty_wilk} srebrzystych wilków.')
        print(f'Posiadasz {miedziana_tarcza} miedzianych tarcz oraz {miedziany_żubr} miedzianych żubrów.')
        print()
        #Zmienic kursy monet wg arkusza kalkulacyjnego dla uproszczenia do 3600 kto wie dlaczego ten wie ;)
        print("1 złota korona = 3 złote denary = 12 złotych cetnarów")
        print("1 złoty cetnar = 3 srebrne korony")
        print("1 srebrna korona = 4 srebrne cetnary = 12 srebrzystych wilków")
        print("1 srebrzysty wilk = 4 miedziane tarcze = 12 miedzianych żubrów")
        print("1 złota korona = 3600 miedzianych żubrów")

        while wybor_usera != 4:

            print("1. Kup jedzenie")
            print("2. Kup broń")
            print("3. Kup elementy zbroi")
            print("4. Menu główne")

            wybor_usera = int(input("Jesteś w menu Finanse. Wybierz działanie (1 - 4): "))
            if wybor_usera == 1:
                print()
                print("Idź na rynek po zapasy ... ")
                print()

            elif wybor_usera == 2:
                print()
                print("Kup dobre ostrze u płatnerza lub kowala ... ")
                print()

            elif wybor_usera == 3:
                print()
                print("Kup porządną zbroję aby lepiej się chronić ... ")
                print()

            elif wybor_usera == 4:
                print()
                print("Wychodzisz do menu głównego ... ")
                print()
                break
            
    elif wybor_usera == 9:
        while wybor_usera != 7:

            print()
            print("1. Mapa lokalna ")
            print("2. Mapa miasta/wsi ")
            print("3. Mapa regionu ")
            print("4. Mapa krainy ")
            print("5. Mapa globalna ")
            print("6. Informacje o rasach")
            print("7. Wyjście do menu głównego")

            wybor_usera = int(input("Jesteś w menu wyboru mapy. Wybież mapę lub wyświetl informacje o rasach: (1 - 7) "))

            if wybor_usera == 1:
                print()
                print("Mapa lokalna ...")
            elif wybor_usera == 2:
                print()
                print("Wyświetlam mapę miasta/wsi")

            # Uzupełnić od 3 do 7




            elif wybor_usera == 6:
                print()
                print("Istnieje 12 ras występujących w grze. Są to: ")
                print("1. Awarowie -            rasa mroku i międzywymiarowa ... opis ...")
                print("2. Deronowie -           rasa mroku, genetycy ...")
                print("3. Tyberowie -           rasa mroku silnie technologiczna, wprowadzająca chaoa i wojny między rasami, krainami...")
                print("4. Nordowie -            rasa neutralna, ludy dalekiej północy, spokojni i długowieczni do 500 lat ...")
                print("5. Olbrzymy -            rasa neutralna ...")
                print("6. Edeńczycy -           rasa światłości, międzywymiarowa ...")
                print("7. Haldejczycy -         rasa światłości, matematycy, uzdrowiciele....")
                print("8. Mix ludzi i aniołów - rasa mroku, starożytna rasa, ponad 140 tysięcy lat")
                print("9. Istoty wodne -        rasa neutralna ..")
                print("10. Przebudzeni -        rasa światłości ")
                print("11. Tworzyciele -        rasa neutralna i międzywymiarowa  ")
                print("12. Ludzie -             rasa światłości, chcą żyć w spokoju ")



            elif wybor_usera == 7:
                break

    elif wybor_usera == 10:
        print()
        print("Wychodzisz z gry. Czy chcesz zapisać grę? T/N ")
        print()
        break