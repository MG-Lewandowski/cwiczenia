
wybor_usera = -1

i = 0
klasa_postaci = ""
level_postaci = 0
hp_postaci = 1

while wybor_usera != 8:
    print("1. Wczytaj grę")
    print("2. Zapisz grę")
    print("3. Wyjście")

    wybor_usera = int(input("Jesteś w menu głównym. Wybierz działanie (1 - 9): "))
    if wybor_usera == 1:

        plik = open("statystyki.txt", "r")
        
        tekst = plik.readlines()
        for linia in tekst:
            i = i + 1
            if i == 0:
                klasa_postaci = linia
            elif i == 1:
                level_postaci = tekst[1]

            elif i == 2:
                hp_postaci = tekst[2]        
            print(linia)
        print(f'Ilość iteracji wynosi:  {i}')  
        print(f'Klasa postaci:  {klasa_postaci}')
        print(f'Level postaci:  {level_postaci}')
        print(f'HP postaci: {hp_postaci}') 
        print(type(klasa_postaci)) 
        print(type(level_postaci))
        print(klasa_postaci)





    if wybor_usera == 1:
        print("---")





    if wybor_usera == 1:
        break