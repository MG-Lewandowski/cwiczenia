


plik = open("statystyki.txt", "r")

if plik.readable():
    print("Zawartość pliku: ")        
    tekst = plik.readlines()
    print(tekst)


    for linia in tekst:
        print(linia)
        print(type(linia))
